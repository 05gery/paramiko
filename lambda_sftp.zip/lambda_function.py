import json
import paramiko

def lambda_handler(event, context):
    hostname = "test.rebex.net"
    port = 22
    username = "demo"
    password = "password"

    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(hostname=hostname, port=port, username=username, password=password)

        sftp = ssh.open_sftp()
        files = sftp.listdir('.')
        print("SFTP connection successful. Files:", files)

        sftp.close()
        ssh.close()

        return {
            'statusCode': 200,
            'body': json.dumps('OK')
        }

    except Exception as e:
        print("SFTP connection failed:", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps(f"Connection failed: {str(e)}")
        }
